package mooc.vandy.java4android.gate.logic;

import java.util.Random;

import mooc.vandy.java4android.gate.ui.OutputInterface;

/**
 * This class uses your Gate class to fill the corral with snails.  We
 * have supplied you will the code necessary to execute as an app.
 * You must fill in the missing logic below.
 */
public class FillTheCorral {
    /**
     * Reference to the OutputInterface.
     */
    private OutputInterface mOut;

    /**
     * Constructor initializes the field.
     */
    FillTheCorral(OutputInterface out) {
        mOut = out;
    }

    // TODO -- Fill your code in here
    public void setCorralGates(Gate[] gate, Random selectDirection)
    {
        //Loop through gates and set their direction
        for(int i = 0; i < gate.length; i++)
        {
            //Get rand boolean. If it's true set gate IN
            //Else set gate OUT
            if(selectDirection.nextBoolean())
            {
                gate[i].open(Gate.IN);
            }
            else
            {
                gate[i].open(Gate.OUT);
            }

            mOut.println("Gate " + i + ": " + gate[i].toString());
        }
    }

    public boolean anyCorralAvailable(Gate[] corral)
    {
        //Loop through gates and check if there is any set to IN
        for(Gate aCorral : corral)
        {
            if (!aCorral.isLocked() && aCorral.getSwingDirection() == Gate.IN)
            {
                return true;
            }
        }

        return false;
    }

    public int corralSnails(Gate[] corral, Random rand)
    {
        int snailOut = 5;
        int attempt = 0;

        //Loop until all snails have been corralled
        while(snailOut > 0)
        {
            attempt += 1;
            int gateNumber = new Random().nextInt(4) + 1;
            int snail = rand.nextInt(snailOut);

            //Check and see if gate is set to IN or OUT
            if(corral[gateNumber].getSwingDirection() == Gate.IN)
            {
                snailOut -= snail;
            }
            else
            {
                snailOut += snail;
            }

            //print the snails status
            mOut.println(snail + " are trying to move through coral " + gateNumber);
        }

        mOut.println("It took " + attempt + " attempts to coral all of the snails.");

        return attempt;
    }
    
}
